# Simplistic Dialog

A Pen created on CodePen.io. Original URL: [https://codepen.io/triss90/pen/gMwRXQ](https://codepen.io/triss90/pen/gMwRXQ).

